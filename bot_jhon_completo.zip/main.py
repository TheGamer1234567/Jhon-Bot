
import discord
import random
import asyncio
import os

intents = discord.Intents.default()
intents.messages = True
intents.message_content = True
client = discord.Client(intents=intents)

# Carregar as falas
with open("falas_jhon_10000.txt", "r", encoding="utf-8") as f:
    falas = [linha.strip() for linha in f if linha.strip()]

# GIFs para cada comando
gifs = {
    "beijo": [
        "https://media.giphy.com/media/l0MYB8Ory7Hqefo9a/giphy.gif",
        "https://media.giphy.com/media/3o6Zt481isNVuQI1l6/giphy.gif"
    ],
    "carinho": [
        "https://media.giphy.com/media/xT8qBepJQv8e0U1uXu/giphy.gif"
    ],
    "provoca": [
        "https://media.giphy.com/media/3o6ZsXa3Cyc1D6ymWw/giphy.gif"
    ],
    "saudade": [
        "https://media.giphy.com/media/3oz8xLd9DJq2l2VFtu/giphy.gif"
    ],
    "manda": [
        "https://media.giphy.com/media/l4pTfx2qLszoacZRS/giphy.gif"
    ],
    "mimo": [
        "https://media.giphy.com/media/l0MYt5jPR6QX5pnqM/giphy.gif"
    ],
    "abraço": [
        "https://media.giphy.com/media/od5H3PmEG5EVq/giphy.gif"
    ],
    "chama": [
        "https://media.giphy.com/media/3oriO0OEd9QIDdllqo/giphy.gif"
    ],
    "elogio": [
        "https://media.giphy.com/media/3oEduSbSGpGaRX2Vri/giphy.gif"
    ],
    "dengo": [
        "https://media.giphy.com/media/3oriO0OEd9QIDdllqo/giphy.gif"
    ],
}

@client.event
async def on_ready():
    print(f'Bot conectado como {client.user}')
    while True:
        canal = discord.utils.get(client.get_all_channels(), name="geral")
        if canal:
            fala = random.choice(falas)
            await canal.send(f"💬 {fala}")
        await asyncio.sleep(14400)  # 4 horas

@client.event
async def on_message(message):
    if message.author == client.user:
        return

    if message.content.startswith("!"):
        comando = message.content[1:].lower()
        if comando in gifs:
            fala = random.choice(falas)
            gif = random.choice(gifs[comando])
            await message.channel.send(f"{fala}
{gif}")

# Coloque seu token no Secrets do Replit com o nome DISCORD_TOKEN
client.run(os.getenv("DISCORD_TOKEN"))
